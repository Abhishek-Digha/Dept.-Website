
 <div class="panel panel-primary" >
			  <div class="panel-heading" style="background-color: #4db8ff;">
			        <h3 class="panel-title" style="text-align: center;"><b>MASTER OF TECHNOLOGY (M.Tech)</b></h3>
			  </div>
			  <div class="panel-body">
			        The Department of Computer Science offers M.Tech courses namely:<br>
			        1. M.Tech(N&IE)<br>
			        2. M.Tech(CSE)
			  </div>
			  <div class="panel-heading" style="background-color:#4dd2ff;">
			        <h3 class="panel-title" style="color: black;" ><b>MODE OF ADMISSION</b></h3>
			  </div>
			  <div class="panel-body">
			        Admission to M.C.A. is based on entrance examination. The entrance examination is of objective type
			  </div>
			  <div class="panel-heading" style="background-color:#80dfff;">
			        <h3 class="panel-title" style="color: black;"><b>SYLLABUS FOR TEST</b></h3>
			  </div>
			  <div class="panel-body">
			         Questions will be from the following subjects:Data Structures and Algorithms, Computer Architecture, Operating Systems, System Software, Microprocessors, DBMS, Networks, Compilers, Automata, AI, Graphics, Software Engineering, Programming Languages (C, C++ and Java) and Recent Trends in Computer Science.
			  </div>
			  <div class="panel-heading" style="background-color:#85e0e0;">
			        <h3 class="panel-title" style="color: black;"><b>RESULT PUBLICATION</b></h3>
			  </div>
			  <div class="panel-body">
			        The list of qualified students will be published on the University website on merit basis and the councelling date will be mentioned there.
			        Rank list will be based on the marks scored in the entrace test.
			  </div>
			  <div class="panel-heading" style="background-color:#85e0e0;">
			        <h3 class="panel-title" style="color: black;"><b>COURSE STRUCTURE</b></h3>
			  </div>
			  <div class="panel-body">
			        This course contains 4 semesters, including 2 projects one in 3th semester i.e Mini Project
			        another is in 4th semester i.e Major Project.      
			  </div>
			  <div class="panel-heading" style="background-color:#85e0e0;">
			        <h3 class="panel-title" style="color: black;"><b>SYLLABUS</b></h3>
			  </div>
			  <div class="panel-body">
			        Academic Syllabus: <a href="http://www.pondiuni.edu.in/sites/default/files/downloads/15.pdf">M.Tech CSE Syllabus click here</a><br>
			        Academic Syllabus: <a href="http://www.pondiuni.edu.in/sites/default/files/downloads/16.pdf">M.Tech N&IE Syllabus click here</a>
			  </div>
</div>

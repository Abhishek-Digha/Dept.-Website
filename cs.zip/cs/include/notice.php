<div class="panel panel-primary" >
			  <div class="panel-heading" style="background-color: #4db8ff;">
			        <h3 class="panel-title" style="text-align: center;"><b>LATEST UPDATES</b></h3>
			  </div>
			  <div class="panel-body">
			        End Semester examination is going on.
			  </div>
			  <div class="panel-heading" style="background-color:#4dd2ff;">
			        <h3 class="panel-title" style="color: black;" ><b>Result Deceleartion</b></h3>
			  </div>
			  <div class="panel-body">
			        End Semester results will be published by Dec 06. 
			  </div>
			  <div class="panel-heading" style="background-color:#80dfff;">
			        <h3 class="panel-title" style="color: black;"><b>Even Semester </b></h3>
			  </div>
			  <div class="panel-body">
			        Even Semester classes will be stated by Dec 09.<br>
                    Winter  vacations will be started by Dec 25 2016 to Jan 15 2017.<br>
                    Classes scheduled will be published soon.

			  </div>
			  <div class="panel-heading" style="background-color:#85e0e0;">
			        <h3 class="panel-title" style="color: black;"><b>Workshop</b></h3>
			  </div>
			  <div class="panel-body">
			        None
			  </div>
			  <div class="panel-heading" style="background-color:#85e0e0;">
			        <h3 class="panel-title" style="color: black;"><b>Extra Curricular Activities</b></h3>
			  </div>
			  <div class="panel-body">
			        None
			  </div>
			  
</div>

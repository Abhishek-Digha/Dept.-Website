
     	<div id="footer" style="background: url(images/body-bg.gif); width: 100%"> 
        <div class="panel panel-primary">
		<div class="panel-heading">
		    <h3 class="panel-title" style="text-align: center;"><b>Quick Links</b></h3>
		</div>
     	</div>
        <div class="panel-body">
		    <div class="row">
			  <div class="col-sm-2" ><a href="http://210.212.230.223/" class="btn btn-success">Library</a></div>
			  <div class="col-sm-3"><a href="http://www.pondiuni.edu.in/computer-center/about-computer-centre" class="btn btn-info">Computer Center</a></div>
			  <div class="col-sm-2"><a href="http://14.139.183.115/moodle/" class="btn btn-warning">E-learning</a></div>
			  <div class="col-sm-2"><a href="http://www.pondiuni.edu.in/content/services" class="btn btn-danger">Services</a></div>
			  <div class="col-sm-2"><a href="http://www.pondiuni.edu.in/" class="btn btn-primary">Main Site</a></div>
			</div>
		</div>
		<div class="panel panel-primary">
		<div class="panel-heading">
		    <h3 class="panel-title" style="text-align: center;"><b>Copyright@Abhishek-2016</b></h3>
		</div>
     	</div>
        </div>
		<script type="text/javascript" src="js/jquery.js"></script>
		<script type="text/javascript" src="js/bootstrap.min.js"></script>
		<script type="text/javascript" src="js/myjs.js"></script>		
		



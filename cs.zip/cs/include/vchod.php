<div class="container-fluid">
  <div class="row">
  <div class="col-sm-4" style="background-color:lavender;">
   		<div class="panel panel-primary">
	      <div class="panel-heading">
	          <h3 class="panel-title"><b>Courses Offered</b></h3>
	      </div>
	        <div class="panel-body">
	             <div class="list-group">
		             <a class="list-group-item active" style="height: 45px;">
		             <td><b>M.C.A</b></td>
		             </a>
	             </div>
	             <div class="list-group">
		             <a class="list-group-item active" style="height: 45px;">
		             <td><b>M.Sc & MSc(Int.5 years)</b></td>
		             </a>
	             </div>
	             <div class="list-group"  >
		             <a class="list-group-item active" style="height: 45px;">
		             <td><b>M.Tech(NIE & CSE)</b></td>
		             </a>
	             </div>
	             <div class="list-group" >
		             <a class="list-group-item active" style="height: 45px;">
		             <td><b>Phd</b></td>
		             </a>
	            </div>
            </div>
        </div>
    </div>
  <div class="col-sm-4" style="background-color:lavender;">
	  <div class="panel panel-primary">
	      <div class="panel-heading">
	          <h3 class="panel-title"><b>Vice Chancellor P.U</b></h3>
	      </div>
          <div class="panel-body">
              <td><img src="images/vc.png" width="100%" height="100%" ></td><br><br>
	             <div class="list-group">
		             <a class="list-group-item active" href="http://www.pondiuni.edu.in/vc-message/vice-chancellor-officiating">
		             <td><b>Prof.(Dr.)Anisha Basir Khan</b></td>
		             <td>(Officiating) </td>
		             </a>
	             </div>
           </div>
      </div>
  </div>
  <div class="col-sm-4" style="background-color:lavender;">
	  <div class="panel panel-primary">
	      <div class="panel-heading">
	          <h3 class="panel-title"><b>Head of Department</b></h3>
	      </div>
          <div class="panel-body">
              <td><img src="images/hod.png" width="100%" height="100%" ></td><br><br>
	             <div class="list-group">
		             <a class="list-group-item active" href="http://www.pondiuni.edu.in/profile/dr-r-subramanian">
		             <td><b>Prof.(Dr) R. Subramanian</b></td>
		             <td>Computer Science</td>
		             </a>
	             </div>
           </div>
      </div>
  </div>
      
  </div>
</div>

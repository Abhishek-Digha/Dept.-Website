 <?php
// Start the session
require 'PHPMailer/PHPMailerAutoload.php';
session_start();
?>
 
 <!DOCTYPE html>
<html lang="en">
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Department of Computer Science  </title>
  <link rel="stylesheet" href="student.css"/>

<body id= "back" >
<head>
<div id="head_div">
<img src="logo.png" alt="logo" >
</div>
</head>
<div id = "navigation">
<nav >
 <ul>
  <li> <a href="./Index.html">Home</a></li>
  <li><a href="./faculty.html">Faculty</a></li>
  <li><a class="active" href="./student.php">Student</a></li>
  <li><a href="./courses.html">Courses</a></li>
  <li><a href="#">Notice Board</a> </li>
  <li><a href="http://www.pondiuni.edu.in/content/contact-us">Contact Us</a> </li>
 </ul> 
</nav>
</div>
<div id="header1">
<h2>Student Portal</h2>
</div>
<div id="left_info">
<h1 id="std_nav">Menu</h1>
<nav >
 <ul>
  <li> <h3><a class="active" href="./student.php">Login</a></h3></li>
  <li><h3><a href="./register.php">Register</a></h3></li>
  <li><h3><a href="./teacher_login.php">Teachers Login</a></h3></li>
  <li><h3><a href="./teacher.php">Teachers Registration</a></h3></li>
  </ul> 
</nav>
</div>
<div id="center_info">
<h3 id="std_intro">Introduction</h3>
<ol>
<li>This protal is intended to display the records related with the students currently studying in the
Department of Computer Science.</li></br>
<li>This will display students details on the login credentials</li></br>
<li>The students have to first register themselves on the registration page, there they will get User Id and Password</li></br>
<li>The Students can also view their result of the each semester</li></br>
<li>The Students can also register their courses for the particular semester</li></br>
</ol>
</div>
<div id="right_info">
<H2 id="login_head">LOGIN</H2>
<?php

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "myDB";
// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
 // Check connection
 if ($conn->connect_error) {
     die("Connection failed: " . $conn->connect_error);
} 
//check user id and password
$id=$pass=$s_regd=$s_course="";
   if (isset($_POST['insert'])) {
   if ($_SERVER["REQUEST_METHOD"] == "POST") {
       $id     = $_POST["id"];
       $pass   = $_POST["pass"];
    }
        $sql = "SELECT regd, course FROM login where id='$id' AND password='$pass'";
        $result = $conn->query($sql);
        if ($result->num_rows > 0) {
     // output data of each row
        $row = $result->fetch_assoc();
		if(!$row["regd"]==NULL){
		$s_regd= $row["regd"];
        $s_course= $row["course"];	   
	    echo 'Login Successful';
		
		$course=$row["course"];
		$_SESSION["favcolor"] = $s_regd;
	    if(strcmp("M.C.A",$course)==0){
			header('location:./student_portal_MCA.php');
		}else{
			header('location:./student_portal_MTECH.php');
		}
	       
	     
		 }
		}else{
		   echo 'Login Unsuccessfull';
	   }
	 
	   
	      
$conn->close();
}
//end of php operation
 ?>


<form method="POST" >
   </br>
   <h4 id="login">User Id:
   &nbsp;&nbsp;&nbsp;&nbsp;<input id="user" type="text" name="id" required style="align:middle" value="<?php echo $s_regd ?>"><br>
  Password:&nbsp;<input id="pass" type="password"  name="pass"  required></h4>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
  <input  class="login" type="submit"  name="insert" value="Login" />
</form>
<a href="./register.php">Click here to Register</a></br>
<a id="myBtn" style="text-decoration:none">Forget Password?</a>
</div>
<div id="footer1">
<marquee behavior="alternate" 
		direction="right"
        onmouseover="this.stop()"
		onmouseleave="this.start()" scrolldelay="500">Note: For any query contact your Head of Department (R Subramaniam)
</marquee>
</div>


<style>
/* The Modal (background) */
.modal {
    display: none; /* Hidden by default */
    position: fixed; /* Stay in place */
    z-index: 1; /* Sit on top */
    padding-top: 100px; /* Location of the box */
    left: 0;
    top: 0;
    width: 100%; /* Full width */
    height: 100%; /* Full height */
    overflow: auto; /* Enable scroll if needed */
    background-color: rgb(0,0,0); /* Fallback color */
    background-color: rgba(0,0,0,0.4); /* Black w/ opacity */
}

/* Modal Content */
.modal-content {
    position: relative;
    background-color: #fefefe;
    margin: auto;
    padding: 0;
    border: 1px solid #888;
    width: 80%;
    box-shadow: 0 4px 8px 0 rgba(0,0,0,0.2),0 6px 20px 0 rgba(0,0,0,0.19);
    -webkit-animation-name: animatetop;
    -webkit-animation-duration: 0.4s;
    animation-name: animatetop;
    animation-duration: 0.4s
}

/* Add Animation */
@-webkit-keyframes animatetop {
    from {top:-300px; opacity:0} 
    to {top:0; opacity:1}
}

@keyframes animatetop {
    from {top:-300px; opacity:0}
    to {top:0; opacity:1}
}

/* The Close Button */
.close {
    color: white;
    float: right;
    font-size: 28px;
    font-weight: bold;
}

.close:hover,
.close:focus {
    color: #000;
    text-decoration: none;
    cursor: pointer;
}

.modal-header {
    padding: 2px 16px;
    background-color: #5cb85c;
    color: white;
}

.modal-body {padding: 2px 16px;}

.modal-footer {
    padding: 2px 16px;
    background-color: #5cb85c;
    color: white;
}
</style>
</head>
<body>
<form method="post">
<!-- Trigger/Open The Modal -->
<!-- The Modal -->
<div id="myModal" class="modal">

  <!-- Modal content -->
  
  <div class="modal-content">
    <div class="modal-header">
      <span class="close">×</span>
      <h2>Forgot Password</h2>
    </div>
    <div class="modal-body">
      <p style="text-align:center"><b>Enter Your Registration No.:</b></p>
	  <p style="Text-align:center"><input  type="text"  name="reset"  required size="20" maxlength="8" /></p>
      <p>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<input  class="login" type="submit"  name="forgot"  value="SUBMIT" /></p>
    </div>
	</form>
	 <div class="modal-footer">
      <h4 style="color:RED">Note: After submit, Kindly check your registered mail for your Password</h4>
    </div>
  </div>

</div>
	<?php
	if(isset($_POST['forgot'])){
		 if ($_SERVER["REQUEST_METHOD"] == "POST") {
         $regd = $_POST["reset"];
		 }
		 $sql = "SELECT name,email FROM s_record where regd= '$regd'";
		 $sql1 = "SELECT password FROM login where regd= '$regd'";
         $result1 = $conn->query($sql1);
         $result = $conn->query($sql);
		 if ($result->num_rows > 0) {
			 while($row = $result->fetch_assoc()) {
			    $rows = $result1->fetch_assoc();
			    $email=$row["email"];
		        $pass=$rows["password"];
        		$name=$row["name"];	
		      }  
				//login section
				$mail = new PHPMailer;
				$mail->isSMTP();
				$mail->Host = 'smtp.gmail.com';
				$mail->SMTPAuth = true;
				$mail->Username = 'ak47myself@gmail.com';
				$mail->Password = '9334550795';
				$mail->SMTPSecure = 'tls';
				//From detail
				$mail->From = 'Pondicherry_University@pondimail.com';
				$mail->FromName = 'Admin@pondiuniv';
				$mail->addAddress($email,$name);
				$mail->addReplyTo('abhishek.digha1990@gmail.com', 'Abhishek Kumar');
				$mail->WordWrap = 50;
                $mail->isHTML(true);
				$mail->Subject = 'FORGOT Pasword';
                $mail->Body    = $pass;
       			if(!$mail->send()) {
                echo "Mail not Sent";
                exit;
                }
                echo "Mail has been sent";
	           }
	}
	?>
   

<script>
// Get the modal
var modal = document.getElementById('myModal');

// Get the button that opens the modal
var btn = document.getElementById("myBtn");

// Get the <span> element that closes the modal
var span = document.getElementsByClassName("close")[0];

// When the user clicks the button, open the modal 
btn.onclick = function() {
    modal.style.display = "block";
}

// When the user clicks on <span> (x), close the modal
span.onclick = function() {
    modal.style.display = "none";
}

// When the user clicks anywhere outside of the modal, close it
window.onclick = function(event) {
    if (event.target == modal) {
        modal.style.display = "none";
    }
}
</script>


</body>
</html>

 <?php
// Start the session
session_start();
?>
 <!DOCTYPE html>
<html lang="en">
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Department of Computer Science  </title>
  <link rel="stylesheet" href="register.css"/>
  <script src="register.js"></script>

  <body id= "back">

<head>

<div id="head_div">
<img src="logo.png" alt="logo" >
</div>
</head>
<div id = "navigation">
<nav >
 <ul>
  <li> <a href="./Index.html">Home</a></li>
  <li><a href="./faculty.html">Faculty</a></li>
  <li><a class="active" href="./student.php">Student</a></li>
  <li><a href="./courses.html">Courses</a></li>
  <li><a href="#">Notice Board</a> </li>
  <li><a href="http://www.pondiuni.edu.in/content/contact-us">Contact Us</a> </li>
 </ul> 
</nav>
</div>
<div id="header1">
<h2>Teacher Portal</h2>
<h2 id="std_intro">New Registration</h2>
</div>
<div id="left_info">
<h1 id="std_nav">Menu</h1>
<nav >
 <ul>
  <li> <h3><a href="./student.php">Login</a></h3></li>
  <li><h3><a   href="./register.php">Register</a></h3></li>
  <li><h3><a  href="./teacher_login.php">Teachers Login</a></h3></li>
  <li><h3><a class="active" href="./teacher.php">Teachers Registration</a></h3></li>
  </ul> 
</nav>
</div>
<div id="center_info">


<?php

        $s_regd= "";
		$s_name= "";
		$s_dept= "";
		$s_course= "";
		$s_id= "";
		$s_pass="";	
		$s_mail="";
$dbhost = 'localhost';
$dbuser = 'root';
$dbpass = '';
$dbname = 'mydb';
$conn = new mysqli($dbhost, $dbuser, $dbpass, $dbname);
if(mysqli_connect_error()) 
{
die("couldn't connect" . $conn->connect_error());
}
 $regd =$alert=$e_otp=$id=$pass=$code="";
 if ($_SERVER["REQUEST_METHOD"] == "POST") {
   $regd   = $_POST["regd"];
}

if(isset($_POST['insert'])){
        if ($_SERVER["REQUEST_METHOD"] == "POST") {
        $id     = $_POST["id"];
        $pass   = $_POST["pass"];
		$e_otp  = $_POST["otp"];
		$code  = $_POST["code"];
		}if($id=="" || $id==" " && $pass=="" || $pass==" " && $e_otp="" || $e_otp=" " && $code="" || $code=" " ){
		$alert='Fill the fields';
		}else{
		$otp= $_SESSION["otp"];
		if($e_otp==$otp){
		$insert = "Insert into t_login(t_regd,code,id, pass) values ('$regd','$code','$id','$pass')" ;
        if($conn->query($insert) === TRUE) {
        echo "<script type='text/javascript'>alert('Registered successfully')</script>";
        } else {
        echo "<script type='text/javascript'>alert('Already Registered / User Id already Taken')</script>";
        }
		}else{
		echo "<script type='text/javascript'>alert('Incorrect OTP')</script>";
		}
$conn->close(); 
      }
    } 
  
else{
$otp="";
$sql = "SELECT t_regd ,name, dept, email FROM t_record where t_regd= '$regd'";
$result = $conn->query($sql);
     if ($result->num_rows > 0) {
    // output data of each row
    while($row = $result->fetch_assoc()) {    
		$s_regd= $row["t_regd"];
		$s_name= $row["name"];
		$s_dept= $row["dept"];
		$s_mail   = $row["email"];
		}
    $_SESSION["mail"]=$s_mail;
	$_SESSION["name"]=$s_name;
	require 'PHPMailer/PHPMailerAutoload.php';
    //login section
    $mail = new PHPMailer;
    $mail->isSMTP();
    $mail->Host = 'smtp.gmail.com';
    $mail->SMTPAuth = true;
    $mail->Username = 'ak47myself@gmail.com';
    $mail->Password = '9334550795';
    $mail->SMTPSecure = 'tls';
    //From detail
    $email=$_SESSION["mail"];
    $name=$_SESSION["name"];
	$mail->From = 'Pondicherry_University@pondimail.com';
	$mail->FromName = 'Admin@pondiuniv';
	$mail->addAddress($email,$name);
	$mail->addReplyTo('abhishek.digha1990@gmail.com', 'Abhishek Kumar');
	$mail->WordWrap = 50;
	$mail->isHTML(true);
	$mail->Subject = 'OTP for account Activation';
	$otp=rand();
	$mail->Body    = $otp;
	$_SESSION["otp"]=$otp;
	if(!$mail->send()) {
   	echo "<script type='text/javascript'>alert('Message could not be sent.( Check Your Internet Connection)')</script>";
	}
	else
	echo "<script type='text/javascript'>alert('Check Your Registered Mail for OTP')</script>"; 
}}
?>


<form name="Id_search" method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]);?>">	
   <h4 id="regd">&nbsp;&nbsp;Enter Registration ID:
   <input type="text" name="regd" style="align:middle" required  value="<?php echo $s_regd ?>"> &nbsp;&nbsp;
   <input type="submit" name="Search" value="Search" >
      <h4>&nbsp;&nbsp;Name:&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;     
   
   <input type="text" name="name" value="<?php echo $s_name ?>" disabled style="align:middle">
   <h4>&nbsp;&nbsp;Department:&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
   <input type="text" name="dept" value="<?php echo $s_dept ?>" disabled style="align:middle">
   <h4>&nbsp;&nbsp;Course Code:&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
   <input type="text" name="code"  style="align:middle">
   <!--mail code php-->
   <h4>&nbsp;&nbsp;OTP Verification:&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
   <input type="text" name="otp" style="align:middle">&nbsp;&nbsp;&nbsp;
   <h4>&nbsp;&nbsp;User Id:&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
   <input type="text" name="id" style="align:middle">
   <h4>&nbsp;&nbsp;Password:&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
   <input type="password" name="pass"    style="align:middle">&nbsp;&nbsp;<?php echo $alert?></br><br>
      &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
	  
	  <input  class="register" type="submit" name="insert" value="Register" />
</form>
</div>

<div id="right_info">
<H2 id="login_head" style="color:white">Instructions to Register</H2>
<ol style="color:red" >
    <li>Enter Registration ID.</li>
	<li>Click on Search button. </li>
	<li>Check your registered mail for OTP</li>
	<li>If Detail found Enter User Id, Password, OTP  and click on Register Buttton. </li>
	<li>If not found, check your Registration No</li>
	<li>If any message/alert throws means you are already Registered Or User Id taken
       by other user.	   </li>
	   
</ol>
</div>

<div id="footer1">
<marquee behavior="alternate" 
		direction="right"
        onmouseover="this.stop()"
		onmouseleave="this.start()" scrolldelay="500">Note: For any query contact your Head of Department (R Subramaniam)
</marquee>
</div>

</body>
</html>


<script type="text/javascript">
function loadNewDoc(){
	
    alert("Session Expired...Login Again ");
	window.location="./student.php";
	}
</script>
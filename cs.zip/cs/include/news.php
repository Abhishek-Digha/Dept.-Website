<div class="w3-content w3-section" id ="pause" >
  <div class="mySlides">Even Semester will start by 09/12/2016</div>
  <div class="mySlides">End Semester examination will start by 10th Nov 2016</div>
  <div class="mySlides">End Semester result will be declared by 08/12/2016</div>
  
</div>

<script>
var myIndex = 0;
carousel();

function carousel() {
    var i;
    var x = document.getElementsByClassName("mySlides");
    for (i = 0; i < x.length; i++) {
       x[i].style.display = "none";  
    }
    myIndex++;
    if (myIndex > x.length) {myIndex = 1}    
    x[myIndex-1].style.display = "block";  
    setTimeout(carousel, 4000); // Change image every 4 seconds
}
</script>

    
	
			<table class="table table-striped table-hover ">
  				<head>
			    	<tr class="w3-blue">
			      		<th width="60%"><div class="logo">
			            <img src="images/logo.png" alt="logo" style=" height: 100%; width:85%;"/>
	                    </th>
			      		<th width="40%" ><div class="mycss" >DEPARTMENT OF COMPUTER SCIENCE</div></th>
			    	</tr>
			    </head>
			</table>
	

<style type="text/css">
.mycss
{
font-weight:normal;color:White;letter-spacing:0pt;word-spacing:0pt;font-size:36px;text-align:left;font-family:times new roman, times, serif;line-height:1;
}
</style>

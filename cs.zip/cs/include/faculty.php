<div class="panel panel-success">
  <div class="panel-heading" style="background-color: #4db8ff;">
    <h1 class="panel-title" style="text-align: center;"><b>Faculties Department of Computer Science</b></h1>
  </div>
  <div class="panel-body">
       <table class="table table-striped table-hover ">
		  
		  <tbody>
		    <tr class="info">
		      <td><a href="http://www.pondiuni.edu.in/profile/dr-r-subramanian">
		      <div class="row" >
				  <div class="col-sm-2"><img src="images/faculty/hod.png" ></div>
				  <div class="col-sm-4"><b>Prof.(Dr) R. Subramanian</b></div>
				  <div class="col-sm-2">Professor and Head of Department </div>
				  <div class="col-sm-4">rsmanian.csc@pondiuni.edu.in</div>
			  </div>
		    </td></a>
		    </tr>

		    <tr class="success">
		       <td><a href="http://www.pondiuni.edu.in/profile/dr-p-dhavachelvan">
		      <div class="row" >
				  <div class="col-sm-2"><img src="images/faculty/dh.jpg" ></div>
				  <div class="col-sm-4"><b>Dr. P. Dhavaclelvan</b></div>
				  <div class="col-sm-2">Professor</div>
				  <div class="col-sm-4">dhavachelvan@gmail.com</div>
			  </div>
		    </td></a>
		       </tr>
		    <tr class="danger">
		       <td><a href="http://www.pondiuni.edu.in/profile/dr-t-chithralekha">
		      <div class="row" >
				  <div class="col-sm-2"><img src="images/faculty/ct.jpg" ></div>
				  <div class="col-sm-4"><b>Dr. T. Chitralekha</b></div>
				  <div class="col-sm-2">Associate Professor  </div>
				  <div class="col-sm-4"></div>
			  </div>
		    </td></a>
		    </tr>
		    <tr class="warning">
		       <td><a href="http://www.pondiuni.edu.in/profile/dr-s-sivasathya">
		      <div class="row" >
				  <div class="col-sm-2"><img src="images/faculty/ssat.jpg" ></div>
				  <div class="col-sm-4"><b>Dr. S. Sivasathya</b></div>
				  <div class="col-sm-2">Associate Professor </div>
				  <div class="col-sm-4">ssivasathya@gmail.com</div>
			  </div>
		    </td></a>
		    </tr>
		    <tr class="active">
		       <td><a href="http://www.pondiuni.edu.in/profile/rp-seenivasan">
		      <div class="row" >
				  <div class="col-sm-2"><img src="images/faculty/sinu.jpg" ></div>
				  <div class="col-sm-4"><b>R.P Seenivasan</b></div>
				  <div class="col-sm-2">Assistant Professor </div>
				  <div class="col-sm-4">rpseenivasan.csc@pondiuni.edu.in</div>
			  </div>
		    </td></a>
		    </tr>
		    <tr class="success">
		       <td><a href="http://www.pondiuni.edu.in/profile/dr-v-uma">
		      <div class="row" >
				  <div class="col-sm-2"><img src="images/faculty/uma.jpg" ></div>
				  <div class="col-sm-4"><b>Dr. V. Uma</b></div>
				  <div class="col-sm-2">Assistant Professor </div>
				  <div class="col-sm-4">umabskr@gmail.com</div>
			  </div>
		    </td></a>
		    </tr>
		    <tr>
		       <td><a href="http://www.pondiuni.edu.in/profile/dr-p-shanthi-bala">
		      <div class="row" >
				  <div class="col-sm-2"><img src="images/faculty/sb.jpg" ></div>
				  <div class="col-sm-4"><b>P. Santhi Bala</b></div>
				  <div class="col-sm-2">Assistant Professor </div>
				  <div class="col-sm-4">shanthibala.csc@pondiuni.edu.in</div>
			  </div>
		    </td></a>
		    </tr>
		    <tr class="info">
		       <td><a href="http://www.pondiuni.edu.in/profile/dr-mnandhini">
		      <div class="row" >
				  <div class="col-sm-2"><img src="images/faculty/nd.png" ></div>
				  <div class="col-sm-4"><b>Dr. M.Nandhini</b></div>
				  <div class="col-sm-2">Assistant Professor </div>
				  <div class="col-sm-4">mnandhini2005@yahoo.com</div>
			  </div>
		    </td></a>
		    </tr>
		    <tr class="success">
		       <td><a href="http://www.pondiuni.edu.in/profile/drt-vengattaraman">
		      <div class="row" >
				  <div class="col-sm-2"><img src="images/faculty/venki.jpg" ></div>
				  <div class="col-sm-4"><b>T. Vengattaraman</b></div>
				  <div class="col-sm-2">Assistant Professor  </div>
				  <div class="col-sm-4">vengattaraman.t@gmail.com</div>
			  </div>
		    </td></a>
		    </tr>
		    <tr class="danger">
		       <td> <a href="http://www.pondiuni.edu.in/profile/dr-r-sunitha">
		      <div class="row" >
				  <div class="col-sm-2"><img src="images/faculty/sunitha.jpg" ></div>
				  <div class="col-sm-4"><b>Dr. R.Sunitha</b></div>
				  <div class="col-sm-2">Assistant Professor </div>
				  <div class="col-sm-4">sunitha.csc@pondiuni.edu.in</div>
			  </div>
		    </td></a>
		    </tr>
		    <tr class="warning">
		       <td><a href="http://www.pondiuni.edu.in/profile/dr-s-ravi">
		      <div class="row" >
				  <div class="col-sm-2"><img src="images/faculty/ravi.jpg" ></div>
				  <div class="col-sm-4"><b>Dr. S. Ravi</b></div>
				  <div class="col-sm-2">Assistant Professor  </div>
				  <div class="col-sm-4"></div>
			  </div>
		    </td></a>
		    </tr>
		    <tr class="active">
		       <td><a href="http://www.pondiuni.edu.in/profile/k-vijayanand">
		      <div class="row" >
				  <div class="col-sm-2"><img src="images/faculty/vj.jpg" ></div>
				  <div class="col-sm-4"><b>K. Vijayanand</b></div>
				  <div class="col-sm-2">Assistant Professor </div>
				  <div class="col-sm-4">kvanand.csc@pondiuni.edu.in</div>
			  </div>
		    </td></a>
		    </tr>
		    <tr class="success">
		       <td><a href="http://www.pondiuni.edu.in/profile/t-sivakumar">
		      <div class="row" >
				  <div class="col-sm-2"><img src="images/faculty/ts.jpg" ></div>
				  <div class="col-sm-4"><b>T.Sivakumar</b></div>
				  <div class="col-sm-2">Assistant Professor  </div>
				  <div class="col-sm-4">tsivakumar72@gmail.com</div>
			  </div>
		    </td></a>
		    </tr>
		    <tr class="danger">
		       <td><a href="http://www.pondiuni.edu.in/profile/dr-pothula-sujatha">
		      <div class="row" >
				  <div class="col-sm-2"><img src="images/faculty/sujju.jpg" ></div>
				  <div class="col-sm-4"><b>Dr. Pothula Sujatha</b></div>
				  <div class="col-sm-2">Assistant Professor </div>
				  <div class="col-sm-4">sujathaps.csc@pondiuni.edu.in</div>
			  </div>
		    </td></a>
		    </tr>
		    <tr class="info">
		       <td><a href="http://www.pondiuni.edu.in/profile/dr-k-suresh-joseph">
		      <div class="row" >
				  <div class="col-sm-2"><img src="images/faculty/jo.jpg" ></div>
				  <div class="col-sm-4"><b>Dr. K. Suresh Joseph</b></div>
				  <div class="col-sm-2">Assistant Professor  </div>
				  <div class="col-sm-4">ksjoseph.csc@gmail.com</div>
			  </div>
		    </td></a>
		    </tr>
		    <tr class="success">
		       <td><a href="http://www.pondiuni.edu.in/profile/m-sathya">
		      <div class="row" >
				  <div class="col-sm-2"><img src="images/faculty/ms.jpg" ></div>
				  <div class="col-sm-4"><b>M. Sathya</b></div>
				  <div class="col-sm-2">Assistant Professor  </div>
				  <div class="col-sm-4">satsubithra@gmail.com</div>
			  </div>
		    </td></a>
		    </tr>
		    <tr class="active">
		       <td><a href="http://www.pondiuni.edu.in/profile/dr-ks-kuppusamy">
		      <div class="row" >
				  <div class="col-sm-2"><img src="images/faculty/ks.png" ></div>
				  <div class="col-sm-4"><b>Dr. K.S Kuppusamy</b></div>
				  <div class="col-sm-2">Assistant Professor </div>
				  <div class="col-sm-4">kskuppu@gmail.com</div>
			  </div>
		    </td></a>
		    </tr>
		    <tr class="danger">
		       <td><a href="http://www.pondiuni.edu.in/profile/skv-jayakumar">
		      <div class="row" >
				  <div class="col-sm-2"><img src="images/faculty/jk.jpg" ></div>
				  <div class="col-sm-4"><b>S.K.V. Jayakumar</b></div>
				  <div class="col-sm-2">Assistant Professor  </div>
				  <div class="col-sm-4">skvjay.csc@pondiuni.edu.in</div>
			  </div>
		    </td></a>
		    </tr>
		  </tbody>
		</table>   
  </div>
</div>
 <?php
// Start the session
session_start();
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "myDB";
$regd="";
// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
 // Check connection
 if ($conn->connect_error) {
     die("Connection failed: " . $conn->connect_error);
}



?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html>

<head>

<title>Student Portal</title>
<link rel="stylesheet" type="text/css" media="screen" href="./student_portal.css" />
<div>
<h1 class="header">STUDENT PORTAL</h1>
<?php
 

if(isset($_POST['LogOut'])){     
       	header('location: ./student.php');
		session_destroy();
        } 
?>
<form name="logout" method="post">
<input id="myBtn" type="Submit" class="logout" name="LogOut" value="Log Out">
 </form>  
</div><br>
</head>
<body >

<div class="form_table">
<?php

//session variable assignment
$regd = $_SESSION["favcolor"];
$sql = "SELECT regd,name,dept,course FROM s_record where regd= '$regd'";
$result = $conn->query($sql);
if ($result->num_rows > 0) {
    // output data of each row
    while($row = $result->fetch_assoc()) { 
?>
<form method="post" id="FSForm">
<div id="q0" class="q required">
<a class="item_anchor" name="ItemAnchor0"></a>
<label class="question top_question" for="RESULT_TextField-0">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Registration No&nbsp;<b class="icon_required" style="color:#FF0000">*</b></label>
<input type="text" name="RESULT_TextField-0" class="text_field read_only" id="RESULT_TextField-0"  size="25" maxlength="255" disabled value="<?php echo $row["regd"]; ?>" />
</div>
<div id="q1" class="q required">
<a class="item_anchor" name="ItemAnchor1"></a>
<label class="question top_question" for="RESULT_TextField-1">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Name&nbsp;<b class="icon_required" style="color:#FF0000">*</b></label>
<input type="text" name="RESULT_TextField-1" class="text_field read_only" id="RESULT_TextField-1"  size="25" maxlength="255" disabled value="<?php echo $row["name"]; ?>" />
</div>
<div id="q2" class="q required">
<a class="item_anchor" name="ItemAnchor2"></a>
<label class="question top_question" for="RESULT_TextField-2">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Department&nbsp;<b class="icon_required" style="color:#FF0000">*</b></label>
<input type="text" name="RESULT_TextField-2" class="text_field read_only" id="RESULT_TextField-2"  size="25" maxlength="255" disabled value="<?php echo $row["dept"]; ?>" />
</div>
<div id="q3" class="q required">
<a class="item_anchor" name="ItemAnchor3"></a>
<label class="question top_question" for="RESULT_TextField-3">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Course&nbsp;&nbsp;&nbsp;<b class="icon_required" style="color:#FF0000">*</b></label>
<input type="text" name="RESULT_TextField-3" class="text_field read_only" id="RESULT_TextField-3"  size="25" maxlength="255" disabled value="<?php echo $row["course"]; ?>" />
</div>
<?php
	}
}


?>
</form>
</div>
<div><br></div>
<!--Student Detail-->
<!-- BEGIN_ITEMS -->
<button class="accordion"><b>SEMESTER COURSE REGISTRATION</b></button>
<div class="panel">
  <div class="form_table">
<div class="clear"></div>
<?php
 
$regd = $_SESSION["favcolor"];

if(isset($_POST['sem1'])){
   		 $s1=$s2=$s3=$s4=$s5=$s6=$s7="";
 if ($_SERVER["REQUEST_METHOD"] == "POST") {
  $s1 = $_POST["RB-1"];
  $s2 = $_POST["RB-2"];
  $s3 = $_POST["RB-3"];
  $s4 = $_POST["RB-4"];
  $s5 = $_POST["RB-5"];
  $s6 = $_POST["RB-6"];
  $s7 = $_POST["RB-7"];
  }
         
		 $insert = "Insert into mca_sem1(regd,COMS301,COMS302,COMS303,COMS304,COMS305,COMS308,COMS309) values ('$regd','$s1','$s2','$s3','$s4','$s5','$s6','$s7')" ;
        if($conn->query($insert) === TRUE) {
        echo "<script type='text/javascript'>alert('Registered successfully')</script>";
        } else {
        echo "<script type='text/javascript'>alert('Already Registered / User Id already Taken')</script>";
		}
		}
		else if(isset($_POST['sem2'])){
   		  if ($_SERVER["REQUEST_METHOD"] == "POST") {
 
   $s8 = $_POST["RB-8"];
    $s9 = $_POST["RB-9"];
	 $s10 = $_POST["RB-10"];
	  $s11 = $_POST["RB-11"];
	   $s12 = $_POST["RB-12"];
	    $s13 = $_POST["RB-13"];
		 $s14 = $_POST["RB-14"];

		 }
		 $insert = "Insert into mca_sem2(regd,COMS351,COMS352,COMS353,COMS358,COMS359,ELECTIVE1,ELECTIVE2) values ('$regd','$s8','$s9','$s10','$s11','$s12','$s13','$s14')" ;
        if($conn->query($insert) === TRUE) {
        echo "<script type='text/javascript'>alert('Registered successfully')</script>";
        } else {
        echo "<script type='text/javascript'>alert('Already Registered / User Id already Taken')</script>";
		}
		}
		//Third semester 
		else if(isset($_POST['sem3'])){
   		  if ($_SERVER["REQUEST_METHOD"] == "POST") {
 
   $s15 = $_POST["RB-15"];
    $s16 = $_POST["RB-16"];
	 $s17 = $_POST["RB-17"];
	  $s18 = $_POST["RB-18"];
	   $s19 = $_POST["RB-19"];
	    $s20 = $_POST["RB-20"];
		 $s21 = $_POST["RB-21"];

		 }
		 $insert = "Insert into mca_sem3(regd,COMS401,COMS402,COMS403,COMS408,COMS409,ELECTIVE3,ELECTIVE4) values ('$regd','$s15','$s16','$s17','$s18','$s19','$s20','$s21')" ;
        if($conn->query($insert) === TRUE) {
        echo "<script type='text/javascript'>alert('Registered successfully')</script>";
        } else {
        echo "<script type='text/javascript'>alert('Already Registered / User Id already Taken')</script>";
		}
		}
		//Fourth Semester
		
		else if(isset($_POST['sem4'])){
   		  if ($_SERVER["REQUEST_METHOD"] == "POST") {
 
   $s22 = $_POST["RB-22"];
    $s23 = $_POST["RB-23"];
	 $s24 = $_POST["RB-24"];
	  $s25 = $_POST["RB-25"];
	   $s26 = $_POST["RB-26"];
	    $s27 = $_POST["RB-27"];
		 $s28 = $_POST["RB-28"];

		 }
		 $insert = "Insert into mca_sem4(regd,COMS451,COMS452,COMS453,COMS458,COMS459,ELECTIVE5,ELECTIVE6) values ('$regd','$s22','$s23','$s24','$s25','$s26','$s27','$s28')" ;
        if($conn->query($insert) === TRUE) {
        echo "<script type='text/javascript'>alert('Registered successfully')</script>";
        } else {
        echo "<script type='text/javascript'>alert('Already Registered / User Id already Taken')</script>";
		}
		}
		//Fifth Semester
		
		else if(isset($_POST['sem5'])){
   		  if ($_SERVER["REQUEST_METHOD"] == "POST") {
 
   $s29 = $_POST["RB-29"];
    $s30 = $_POST["RB-30"];
	 $s31 = $_POST["RB-31"];
	  $s32 = $_POST["RB-32"];
	   $s33 = $_POST["RB-33"];
	    $s34 = $_POST["RB-34"];
		 $s35 = $_POST["RB-35"];

		 }
		 $insert = "Insert into mca_sem5(regd,COMS501,COMS502,COMS508,COMS509,ELECTIVE7,ELECTIVE8,ELECTIVE9) values ('$regd','$s29','$s30','$s31','$s32','$s33','$s34','$s35')" ;
        if($conn->query($insert) === TRUE) {
        echo "<script type='text/javascript'>alert('Registered successfully')</script>";
        } else {
        echo "<script type='text/javascript'>alert('Already Registered / User Id already Taken')</script>";
		}
		}
		
		else if(isset($_POST['sem6'])){
   		  if ($_SERVER["REQUEST_METHOD"] == "POST") {
 
   $s36 = $_POST["RB-36"];
    $s37 = $_POST["RB-37"];
	 $s38 = $_POST["RB-38"];
	 }
		 $insert = "Insert into mca_sem6(regd,COMS561,COMS562,COMS563) values ('$regd','$s36','$s37','$s38')" ;
        if($conn->query($insert) === TRUE) {
        echo "<script type='text/javascript'>alert('Registered successfully')</script>";
        } else {
        echo "<script type='text/javascript'>alert('Already Registered / User Id already Taken')</script>";
		}
		}
		
		
?>
<!--First Sem-->
<?php
$sql = "SELECT * FROM mca_sem1 where regd= '$regd'";
$result = $conn->query($sql);
$row = $result->fetch_assoc(); 
?>
<form class="first" method="POST">
<div class="clear"></div>
<div id="q5" class="q required">
<a class="item_anchor" name="ItemAnchor4"></a>
<label class="question top_question" for="RESULT_RadioButton-4">&nbsp;First Semester :&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;<b class="icon_required" style="color:#FF0000">*</b></label>
<select id="RB-4" name="RB-1" class="drop_down" required>
<option><?php echo $row["COMS301"]; ?></option>
<option value="COMS301">COMS-301</option>
</select>
</div>
<div id="q6" class="q required">
<a class="item_anchor" name="ItemAnchor5"></a>
<label class="question top_question" for="RESULT_RadioButton-5">&nbsp;<b class="icon_required" style="color:#FF0000">*</b></label>
<select id="RB-5" name="RB-2" class="drop_down" required>
<option><?php echo $row["COMS302"]; ?></option>
<option value="COMS302">COMS-302</option>
</select>
</div>
<div id="q4" class="q required">
<a class="item_anchor" name="ItemAnchor6"></a>
<label class="question top_question" for="RESULT_RadioButton-6">&nbsp;<b class="icon_required" style="color:#FF0000">*</b></label>
<select id="RB-6" name="RB-3" class="drop_down" required>
<option><?php echo $row["COMS303"]; ?></option>
<option value="COMS303">COMS-303</option>
</select>
</div>
<div id="q7" class="q required">
<a class="item_anchor" name="ItemAnchor7"></a>
<label class="question top_question" for="RESULT_RadioButton-7">&nbsp;<b class="icon_required" style="color:#FF0000">*</b></label>
<select id="RB-7" name="RB-4" class="drop_down" required>
<option><?php echo $row["COMS304"]; ?></option>
<option value="COMS304">COMS-304</option>
</select>
</div>
<div id="q8" class="q required">
<a class="item_anchor" name="ItemAnchor8"></a>
<label class="question top_question" for="RESULT_RadioButton-8">&nbsp;<b class="icon_required" style="color:#FF0000">*</b></label>
<select id="RB-8" name="RB-5" class="drop_down" required>
<option><?php echo $row["COMS305"]; ?></option>
<option value="COMS305">COMS-305</option>
</select>
</div>
<div id="q9" class="q required">
<a class="item_anchor" name="ItemAnchor9"></a>
<label class="question top_question" for="RESULT_RadioButton-9">&nbsp;<b class="icon_required" style="color:#FF0000">*</b></label>
<select id="RB-9" name="RB-6" class="drop_down" required>
<option><?php echo $row["COMS308"]; ?></option>
<option value="COMS308">COMS-308</option>
</select>
</div>
<div id="q10" class="q required">
<a class="item_anchor" name="ItemAnchor10"></a>
<label class="question top_question" for="RESULT_RadioButton-10">&nbsp;<b class="icon_required" style="color:#FF0000">*</b></label>
<select id="RB-10" name="RB-7" class="drop_down" required>
<option><?php echo $row["COMS309"]; ?></option>
<option value="COMS309">COMS-309</option>
</select>
</div>
<div id="q10" class="q required">
<a class="item_anchor" name="ItemAnchor10"></a>

<input type="submit" name="sem1" value="Register" id="sem1">
</div>
</form>
<br><br>
<!--Second Sem-->
<?php
$sql = "SELECT * FROM mca_sem2 where regd= '$regd'";
$result = $conn->query($sql);
$row = $result->fetch_assoc(); 
?>
<form class="second" method="POST">
<div id="q11" class="q required">
<a class="item_anchor" name="ItemAnchor11"></a>
<label class="question top_question" for="RESULT_RadioButton-11">&nbsp;Second Semester :&nbsp;<b class="icon_required" style="color:#FF0000">*</b></label>
<select id="RESULT_RadioButton-11" name="RB-8" class="drop_down" required>
<option><?php echo $row["COMS351"]; ?></option>
<option value="COMS351">COMS-351</option>
</select>
</div>

<div class="clear"></div>

<div id="q12" class="q required">
<a class="item_anchor" name="ItemAnchor12"></a>
<label class="question top_question" for="RESULT_RadioButton-12">&nbsp;<b class="icon_required" style="color:#FF0000">*</b></label>
<select id="RESULT_RadioButton-12" name="RB-9" class="drop_down"required>
<option><?php echo $row["COMS352"]; ?></option>
<option value="COMS352">COMS-352</option>
</select>
</div>
<div id="q13" class="q required">
<a class="item_anchor" name="ItemAnchor13"></a>
<label class="question top_question" for="RESULT_RadioButton-13">&nbsp;<b class="icon_required" style="color:#FF0000">*</b></label>
<select id="RESULT_RadioButton-13" name="RB-10" class="drop_down"required>
<option><?php echo $row["COMS353"]; ?></option>
<option value="COMS353">COMS-353</option>
</select>
</div>
<div id="q14" class="q required">
<a class="item_anchor" name="ItemAnchor14"></a>
<label class="question top_question" for="RESULT_RadioButton-14">&nbsp;<b class="icon_required" style="color:#FF0000">*</b></label>
<select id="RESULT_RadioButton-14" name="RB-11" class="drop_down" required>
<option><?php echo $row["COMS358"]; ?></option>
<option value="COMS358">COMS-358</option>
</select>
</div>
<div id="q15" class="q required">
<a class="item_anchor" name="ItemAnchor15"></a>
<label class="question top_question" for="RESULT_RadioButton-15">&nbsp;<b class="icon_required" style="color:#FF0000">*</b></label>
<select id="RESULT_RadioButton-15" name="RB-12" class="drop_down" required>
<option><?php echo $row["COMS359"]; ?></option>
<option value="COMS359">COMS-359</option>
</select>
</div>
<div id="q16" class="q required">
<a class="item_anchor" name="ItemAnchor16"></a>
<label class="question top_question" for="RESULT_RadioButton-16">&nbsp;<b class="icon_required" style="color:#FF0000">*</b></label>
<select id="RESULT_RadioButton-16" name="RB-13" class="drop_down" required>
<option></option>
<option value="COMS521">COMS-521</option>
<option value="COMS522">COMS-522</option>
</select>
</div>
<div id="q17" class="q required">
<a class="item_anchor" name="ItemAnchor17"></a>
<label class="question top_question" for="RESULT_RadioButton-17">&nbsp;<b class="icon_required" style="color:#FF0000">*</b></label>
<select id="RESULT_RadioButton-17" name="RB-14" class="drop_down" required>
<option></option>
<option value="COMS523">COMS-523</option>
<option value="COMS524">COMS-524</option>
</select>
</div>
<div id="q10" class="q required">
<a class="item_anchor" name="ItemAnchor10"></a>

<input type="submit" name="sem2" value="Register" id="sem2">
</div>
<br><br>
</form>
<!--Third Sem-->
<?php
$sql = "SELECT * FROM mca_sem3 where regd= '$regd'";
$result = $conn->query($sql);
$row = $result->fetch_assoc(); 
?>
<form class="third" method="POST">
<div id="q18" class="q required">
<a class="item_anchor" name="ItemAnchor18"></a>
<label class="question top_question" for="RESULT_RadioButton-18">&nbsp;Third Semester :&nbsp;&nbsp;&nbsp;&nbsp;<b class="icon_required" style="color:#FF0000">*</b></label>
<select id="RESULT_RadioButton-18" name="RB-15" class="drop_down" required>
<option><?php echo $row["COMS401"]; ?></option>
<option value="COMS401">COMS-401</option>
</select>
</div>
<div id="q19" class="q required">
<a class="item_anchor" name="ItemAnchor19"></a>
<label class="question top_question" for="RESULT_RadioButton-19">&nbsp;<b class="icon_required" style="color:#FF0000">*</b></label>
<select id="RESULT_RadioButton-19" name="RB-16" class="drop_down" required>
<option><?php echo $row["COMS402"]; ?></option>
<option value="COMS402">COMS-402</option>
</select>
</div>
<div id="q20" class="q required">
<a class="item_anchor" name="ItemAnchor20"></a>
<label class="question top_question" for="RESULT_RadioButton-20">&nbsp;<b class="icon_required" style="color:#FF0000">*</b></label>
<select id="RESULT_RadioButton-20" name="RB-17" class="drop_down" required>
<option><?php echo $row["COMS403"]; ?></option>
<option value="COMS403">COMS-403</option>
</select>
</div>

<div class="clear"></div>

<div id="q21" class="q required">
<a class="item_anchor" name="ItemAnchor21"></a>
<label class="question top_question" for="RESULT_RadioButton-21">&nbsp;<b class="icon_required" style="color:#FF0000">*</b></label>
<select id="RESULT_RadioButton-21" name="RB-18" class="drop_down" required>
<option><?php echo $row["COMS408"]; ?></option>
<option value="COMS408">COMS-408</option>
</select>
</div>
<div id="q22" class="q required">
<a class="item_anchor" name="ItemAnchor22"></a>
<label class="question top_question" for="RESULT_RadioButton-22">&nbsp;<b class="icon_required" style="color:#FF0000">*</b></label>
<select id="RESULT_RadioButton-22" name="RB-19" class="drop_down" required>
<option><?php echo $row["COMS409"]; ?></option>
<option value="COMS409">COMS-409</option>
</select>
</div>
<div id="q23" class="q required">
<a class="item_anchor" name="ItemAnchor23"></a>
<label class="question top_question" for="RESULT_RadioButton-23">&nbsp;<b class="icon_required" style="color:#FF0000">*</b></label>
<select id="RESULT_RadioButton-23" name="RB-20" class="drop_down" required>
<option></option>
<option value="COMS525">COMS-525</option>
<option value="COMS526">COMS-526</option>
</select>
</div>
<div id="q24" class="q required">
<a class="item_anchor" name="ItemAnchor24"></a>
<label class="question top_question" for="RESULT_RadioButton-24">&nbsp;<b class="icon_required" style="color:#FF0000">*</b></label>
<select id="RESULT_RadioButton-24" name="RB-21" class="drop_down" required>
<option></option>
<option value="COMS527">COMS-527</option>
<option value="COMS528">COMS-528</option>
</select>
</div>
<div id="q10" class="q required">
<a class="item_anchor" name="ItemAnchor10"></a>

<input type="submit" name="sem3" value="Register" id="sem3">
</div>
</form>
<br><br>
<!--Fourth Sem-->
<?php
$sql = "SELECT * FROM mca_sem4 where regd= '$regd'";
$result = $conn->query($sql);
$row = $result->fetch_assoc(); 
?>
<form class="fourth" method="POST">
<div id="q25" class="q required">
<a class="item_anchor" name="ItemAnchor25"></a>
<label class="question top_question" for="RESULT_RadioButton-25">&nbsp;Fourth Semester :&nbsp;&nbsp;<b class="icon_required" style="color:#FF0000">*</b></label>
<select id="RESULT_RadioButton-25" name="RB-22" class="drop_down" required>
<option><?php echo $row["COMS451"]; ?></option>
<option value="COMS451">COMS-451</option>
</select>
</div>
<div id="q26" class="q required">
<a class="item_anchor" name="ItemAnchor26"></a>
<label class="question top_question" for="RESULT_RadioButton-26">&nbsp;<b class="icon_required" style="color:#FF0000">*</b></label>
<select id="RESULT_RadioButton-26" name="RB-23" class="drop_down" required>
<option><?php echo $row["COMS452"]; ?></option>
<option value="COMS452">COMS-452</option>
</select>
</div>
<div id="q27" class="q required">
<a class="item_anchor" name="ItemAnchor27"></a>
<label class="question top_question" for="RESULT_RadioButton-27">&nbsp;<b class="icon_required" style="color:#FF0000">*</b></label>
<select id="RESULT_RadioButton-27" name="RB-24" class="drop_down" required>
<option><?php echo $row["COMS453"]; ?></option>
<option value="COMS453">COMS-453</option>
</select>
</div>
<div id="q28" class="q required">
<a class="item_anchor" name="ItemAnchor28"></a>
<label class="question top_question" for="RESULT_RadioButton-28">&nbsp;<b class="icon_required" style="color:#FF0000">*</b></label>
<select id="RESULT_RadioButton-28" name="RB-25" class="drop_down" required>
<option><?php echo $row["COMS458"]; ?></option>
<option value="COMS458">COMS-458</option>
</select>
</div>

<div class="clear"></div>

<div id="q29" class="q required">
<a class="item_anchor" name="ItemAnchor29"></a>
<label class="question top_question" for="RESULT_RadioButton-29">&nbsp;<b class="icon_required" style="color:#FF0000">*</b></label>
<select id="RESULT_RadioButton-29" name="RB-26" class="drop_down" required>
<option><?php echo $row["COMS459"]; ?></option>
<option value="COMS459">COMS-459</option>
</select>
</div>
<div id="q30" class="q required">
<a class="item_anchor" name="ItemAnchor30"></a>
<label class="question top_question" for="RESULT_RadioButton-30">&nbsp;<b class="icon_required" style="color:#FF0000">*</b></label>
<select id="RESULT_RadioButton-30" name="RB-27" class="drop_down" required>
<option></option>
<option value="COMS529">COMS-529</option>
<option value="COMS530">COMS-530</option>
</select>
</div>
<div id="q31" class="q required">
<a class="item_anchor" name="ItemAnchor31"></a>
<label class="question top_question" for="RESULT_RadioButton-31">&nbsp;<b class="icon_required" style="color:#FF0000">*</b></label>
<select id="RESULT_RadioButton-31" name="RB-28" class="drop_down" required>
<option></option>
<option value="COMS531">COMS-531</option>
<option value="COMS532">COMS-532</option>
</select>
</div>
<div id="q10" class="q required">
<a class="item_anchor" name="ItemAnchor10"></a>

<input type="submit" name="sem4" value="Register" id="sem4">
</div>
</form>
<br><br>
<!--Fifth Sem-->
<?php
$sql = "SELECT * FROM mca_sem5 where regd= '$regd'";
$result = $conn->query($sql);
$row = $result->fetch_assoc(); 
?>
<form class="fifth" method="POST">
<div id="q32" class="q required">
<a class="item_anchor" name="ItemAnchor32"></a>
<label class="question top_question" for="RESULT_RadioButton-32">&nbsp;Fifth Semester :&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<b class="icon_required" style="color:#FF0000">*</b></label>
<select id="RESULT_RadioButton-32" name="RB-29" class="drop_down" required>
<option><?php echo $row["COMS501"]; ?></option>
<option value="COMS501">COMS-501</option>
</select>
</div>
<div id="q33" class="q required">
<a class="item_anchor" name="ItemAnchor33"></a>
<label class="question top_question" for="RESULT_RadioButton-33">&nbsp;<b class="icon_required" style="color:#FF0000">*</b></label>
<select id="RESULT_RadioButton-33" name="RB-30" class="drop_down" required>
<option><?php echo $row["COMS502"]; ?></option>
<option value="COMS502">COMS-502</option>
</select>
</div>
<div id="q34" class="q required">
<a class="item_anchor" name="ItemAnchor34"></a>
<label class="question top_question" for="RESULT_RadioButton-34">&nbsp;<b class="icon_required" style="color:#FF0000">*</b></label>
<select id="RESULT_RadioButton-34" name="RB-31" class="drop_down" required>
<option><?php echo $row["COMS508"]; ?></option>
<option value="COMS508">COMS-508</option>
</select>
</div>
<div id="q35" class="q required">
<a class="item_anchor" name="ItemAnchor35"></a>
<label class="question top_question" for="RESULT_RadioButton-35">&nbsp;<b class="icon_required" style="color:#FF0000">*</b></label>
<select id="RESULT_RadioButton-35" name="RB-32" class="drop_down" required>
<option><?php echo $row["COMS509"]; ?></option>
<option value="COMS509">COMS-509</option>
</select>
</div>
<div id="q36" class="q required">
<a class="item_anchor" name="ItemAnchor36"></a>
<label class="question top_question" for="RESULT_RadioButton-36">&nbsp;<b class="icon_required" style="color:#FF0000">*</b></label>
<select id="RESULT_RadioButton-36" name="RB-33" class="drop_down" required>
<option></option>
<option value="COMS533">COMS-533</option>
<option value="COMS534">COMS-534</option>
</select>
</div>

<div class="clear"></div>

<div id="q37" class="q required">
<a class="item_anchor" name="ItemAnchor37"></a>
<label class="question top_question" for="RESULT_RadioButton-37">&nbsp;<b class="icon_required" style="color:#FF0000">*</b></label>
<select id="RESULT_RadioButton-37" name="RB-34" class="drop_down" required>
<option></option>
<option value="COMS535">COMS-535</option>
<option value="COMS536">COMS-536</option>
</select>
</div>
<div id="q38" class="q required">
<a class="item_anchor" name="ItemAnchor38"></a>
<label class="question top_question" for="RESULT_RadioButton-38">&nbsp;<b class="icon_required" style="color:#FF0000">*</b></label>
<select id="RESULT_RadioButton-38" name="RB-35" class="drop_down" required>
<option></option>
<option value="COMS537">COMS-537</option>
<option value="COMS538">COMS-538</option>
</select>
</div>
<div id="q10" class="q required">
<a class="item_anchor" name="ItemAnchor10"></a>

<input type="submit" name="sem5" value="Register" id="sem5">
</div>
</form>
<br><br>
<!--Sixth Sem-->
<?php
$sql = "SELECT * FROM mca_sem6 where regd= '$regd'";
$result = $conn->query($sql);
$row = $result->fetch_assoc(); 
?>
<form class="sixth" method="POST">
<div id="q39" class="q required">
<a class="item_anchor" name="ItemAnchor39"></a>
<label class="question top_question" for="RESULT_RadioButton-39">&nbsp;Sixth Semester :&nbsp;&nbsp;&nbsp;&nbsp;<b class="icon_required" style="color:#FF0000">*</b></label>
<select id="RESULT_RadioButton-39" name="RB-36" class="drop_down" required>
<option><?php echo $row["COMS561"]; ?></option>
<option value="COMS561">COMS-561</option>
</select>
</div>
<div id="q40" class="q required">
<a class="item_anchor" name="ItemAnchor40"></a>
<label class="question top_question" for="RESULT_RadioButton-40">&nbsp;<b class="icon_required" style="color:#FF0000">*</b></label>
<select id="RESULT_RadioButton-40" name="RB-37" class="drop_down" required>
<option><?php echo $row["COMS562"]; ?></option>
<option value="COMS562">COMS-562</option>
</select>
</div>
<div id="q41" class="q required">
<a class="item_anchor" name="ItemAnchor41"></a>
<label class="question top_question" for="RESULT_RadioButton-41">&nbsp;<b class="icon_required" style="color:#FF0000">*</b></label>
<select id="RESULT_RadioButton-41" name="RB-38" class="drop_down" required>
<option><?php echo $row["COMS563"]; ?></option>
<option value="COMS563">COMS-563</option>
</select>
</div>
<div id="q10" class="q required">
<a class="item_anchor" name="ItemAnchor10"></a>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
<input type="submit" name="sem6" value="Register" id="sem6">
</div>
</form>
</div>
</div>
<div><br></div>

<button class="accordion"><b>RESULTS</b></button>
<div class="panel">
<div class="form_table">
<div class="clear"></div>
<!-- Php code to show result-->  
    <?php 
	$regd = $_SESSION["favcolor"];
	$sql = "SELECT * FROM s_mark where regd= '$regd'";
	$result = $conn->query($sql);
	if ($result->num_rows > 0) {
    // output data of each row
    while($row = $result->fetch_assoc()) { 
	?>

<div id="q1" class="q">
<a class="item_anchor" name="ItemAnchor0"></a>
<label class="question top_question" for="RESULT_TextField-0">First Sem :</label>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
<input type="text" name="RESULT_TextField-0" class="text_field read_only" id="RESULT_TextField-0"  size="5" maxlength="255" disabled value="<?php echo $row["COMS301"]; ?>" />
</div>
<div id="q2" class="q">
<a class="item_anchor" name="ItemAnchor1"></a>
<label class="question top_question" for="RESULT_TextField-1"></label>
<input type="text" name="RESULT_TextField-1" class="text_field read_only" id="RESULT_TextField-1"  size="5" maxlength="255" disabled value="<?php echo $row["COMS302"]; ?>" />
</div>
<div id="q3" class="q">
<a class="item_anchor" name="ItemAnchor2"></a>
<label class="question top_question" for="RESULT_TextField-2"></label>
<input type="text" name="RESULT_TextField-2" class="text_field read_only" id="RESULT_TextField-2"  size="5" maxlength="255" disabled value="<?php echo $row["COMS303"]; ?>" />
</div>
<div id="q4" class="q">
<a class="item_anchor" name="ItemAnchor3"></a>
<label class="question top_question" for="RESULT_TextField-3"></label>
<input type="text" name="RESULT_TextField-3" class="text_field read_only" id="RESULT_TextField-3"  size="5" maxlength="255" disabled value="<?php echo $row["COMS304"]; ?>" />
</div>
<div id="q5" class="q">
<a class="item_anchor" name="ItemAnchor4"></a>
<label class="question top_question" for="RESULT_TextField-4"></label>
<input type="text" name="RESULT_TextField-4" class="text_field read_only" id="RESULT_TextField-4"  size="5" maxlength="255" disabled value="<?php echo $row["COMS305"]; ?>" />
</div>
<div id="q6" class="q">
<a class="item_anchor" name="ItemAnchor5"></a>
<label class="question top_question" for="RESULT_TextField-5"></label>
<input type="text" name="RESULT_TextField-5" class="text_field read_only" id="RESULT_TextField-5"  size="5" maxlength="255" disabled value="<?php echo $row["COMS308"]; ?>" />
</div>
<div id="q7" class="q">
<a class="item_anchor" name="ItemAnchor6"></a>
<label class="question top_question" for="RESULT_TextField-6"></label>
<input type="text" name="RESULT_TextField-6" class="text_field read_only" id="RESULT_TextField-6"  size="5" maxlength="255" disabled value="<?php echo $row["COMS309"]; ?>" />
</div>
<div id="q8" class="q">
<a class="item_anchor" name="ItemAnchor7"></a>
<label class="question top_question" for="RESULT_TextField-7"></label>
<input type="text" name="RESULT_TextField-7" class="text_field read_only" id="RESULT_TextField-7"  size="5" maxlength="255" disabled value="" />
</div>
<br><br>
<div class="clear"></div>

<div id="q9" class="q">
<a class="item_anchor" name="ItemAnchor8"></a>
<label class="question top_question" for="RESULT_TextField-8">Second Sem :</label>
<input type="text" name="RESULT_TextField-8" class="text_field read_only" id="RESULT_TextField-8"  size="5" maxlength="255" disabled value="<?php echo $row["COMS351"]; ?>" />
</div>
<div id="q10" class="q">
<a class="item_anchor" name="ItemAnchor9"></a>
<label class="question top_question" for="RESULT_TextField-9"></label>
<input type="text" name="RESULT_TextField-9" class="text_field read_only" id="RESULT_TextField-9"  size="5" maxlength="255" disabled value="<?php echo $row["COMS352"]; ?>" />
</div>
<div id="q11" class="q">
<a class="item_anchor" name="ItemAnchor10"></a>
<label class="question top_question" for="RESULT_TextField-10"></label>
<input type="text" name="RESULT_TextField-10" class="text_field read_only" id="RESULT_TextField-10"  size="5" maxlength="255" disabled value="<?php echo $row["COMS353"]; ?>" />
</div>
<div id="q12" class="q">
<a class="item_anchor" name="ItemAnchor11"></a>
<label class="question top_question" for="RESULT_TextField-11"></label>
<input type="text" name="RESULT_TextField-11" class="text_field read_only" id="RESULT_TextField-11"  size="5" maxlength="255" disabled value="<?php echo $row["COMS358"]; ?>" />
</div>
<div id="q13" class="q">
<a class="item_anchor" name="ItemAnchor12"></a>
<label class="question top_question" for="RESULT_TextField-12"></label>
<input type="text" name="RESULT_TextField-12" class="text_field read_only" id="RESULT_TextField-12"  size="5" maxlength="255" disabled value="<?php echo $row["COMS359"]; ?>" />
</div>
<div id="q14" class="q">
<a class="item_anchor" name="ItemAnchor13"></a>
<label class="question top_question" for="RESULT_TextField-13"></label>
<input type="text" name="RESULT_TextField-13" class="text_field read_only" id="RESULT_TextField-13"  size="5" maxlength="255" disabled value="<?php echo $row["ELECTIVE1"]; ?>" />
</div>
<div id="q15" class="q">
<a class="item_anchor" name="ItemAnchor14"></a>
<label class="question top_question" for="RESULT_TextField-14"></label>
<input type="text" name="RESULT_TextField-14" class="text_field read_only" id="RESULT_TextField-14"  size="5" maxlength="255" disabled value="<?php echo $row["ELECTIVE2"]; ?>" />
</div>
<div id="q16" class="q">
<a class="item_anchor" name="ItemAnchor15"></a>
<label class="question top_question" for="RESULT_TextField-15"></label>
<input type="text" name="RESULT_TextField-15" class="text_field read_only" id="RESULT_TextField-15"  size="5" maxlength="255" disabled value="" />
</div>
<br><br>
<div class="clear"></div>

<div id="q17" class="q">
<a class="item_anchor" name="ItemAnchor16"></a>
<label class="question top_question" for="RESULT_TextField-16">Third Sem :</label>&nbsp;&nbsp;&nbsp;&nbsp;
<input type="text" name="RESULT_TextField-16" class="text_field read_only" id="RESULT_TextField-16"  size="5" maxlength="255" disabled value="<?php echo $row["COMS401"]; ?>" />
</div>
<div id="q18" class="q">
<a class="item_anchor" name="ItemAnchor17"></a>
<label class="question top_question" for="RESULT_TextField-17"></label>
<input type="text" name="RESULT_TextField-17" class="text_field read_only" id="RESULT_TextField-17"  size="5" maxlength="255" disabled value="<?php echo $row["COMS402"]; ?>" />
</div>
<div id="q19" class="q">
<a class="item_anchor" name="ItemAnchor18"></a>
<label class="question top_question" for="RESULT_TextField-18"></label>
<input type="text" name="RESULT_TextField-18" class="text_field read_only" id="RESULT_TextField-18"  size="5" maxlength="255" disabled value="<?php echo $row["COMS403"]; ?>" />
</div>
<div id="q20" class="q">
<a class="item_anchor" name="ItemAnchor19"></a>
<label class="question top_question" for="RESULT_TextField-19"></label>
<input type="text" name="RESULT_TextField-19" class="text_field read_only" id="RESULT_TextField-19"  size="5" maxlength="255" disabled value="<?php echo $row["COMS408"]; ?>" />
</div>
<div id="q21" class="q">
<a class="item_anchor" name="ItemAnchor20"></a>
<label class="question top_question" for="RESULT_TextField-20"></label>
<input type="text" name="RESULT_TextField-20" class="text_field read_only" id="RESULT_TextField-20"  size="5" maxlength="255" disabled value="<?php echo $row["COMS409"]; ?>" />
</div>
<div id="q22" class="q">
<a class="item_anchor" name="ItemAnchor21"></a>
<label class="question top_question" for="RESULT_TextField-21"></label>
<input type="text" name="RESULT_TextField-21" class="text_field read_only" id="RESULT_TextField-21"  size="5" maxlength="255" disabled value="<?php echo $row["ELECTIVE3"]; ?>" />
</div>
<div id="q23" class="q">
<a class="item_anchor" name="ItemAnchor22"></a>
<label class="question top_question" for="RESULT_TextField-22"></label>
<input type="text" name="RESULT_TextField-22" class="text_field read_only" id="RESULT_TextField-22"  size="5" maxlength="255" disabled value="<?php echo $row["ELECTIVE4"]; ?>" />
</div>
<div id="q24" class="q">
<a class="item_anchor" name="ItemAnchor23"></a>
<label class="question top_question" for="RESULT_TextField-23"></label>
<input type="text" name="RESULT_TextField-23" class="text_field read_only" id="RESULT_TextField-23"  size="5" maxlength="255" disabled value="" />
</div>
<br><br>
<div class="clear"></div>

<div id="q25" class="q">
<a class="item_anchor" name="ItemAnchor24"></a>
<label class="question top_question" for="RESULT_TextField-24">Fourth Sem:</label>&nbsp;&nbsp;&nbsp;
<input type="text" name="RESULT_TextField-24" class="text_field read_only" id="RESULT_TextField-24"  size="5" maxlength="255" disabled value="<?php echo $row["COMS451"]; ?>" />
</div>
<div id="q26" class="q">
<a class="item_anchor" name="ItemAnchor25"></a>
<label class="question top_question" for="RESULT_TextField-25"></label>
<input type="text" name="RESULT_TextField-25" class="text_field read_only" id="RESULT_TextField-25"  size="5" maxlength="255" disabled value="<?php echo $row["COMS452"]; ?>" />
</div>
<div id="q27" class="q">
<a class="item_anchor" name="ItemAnchor26"></a>
<label class="question top_question" for="RESULT_TextField-26"></label>
<input type="text" name="RESULT_TextField-26" class="text_field read_only" id="RESULT_TextField-26"  size="5" maxlength="255" disabled value="<?php echo $row["COMS453"]; ?>" />
</div>
<div id="q28" class="q">
<a class="item_anchor" name="ItemAnchor27"></a>
<label class="question top_question" for="RESULT_TextField-27"></label>
<input type="text" name="RESULT_TextField-27" class="text_field read_only" id="RESULT_TextField-27"  size="5" maxlength="255" disabled value="<?php echo $row["COMS458"]; ?>" />
</div>
<div id="q29" class="q">
<a class="item_anchor" name="ItemAnchor28"></a>
<label class="question top_question" for="RESULT_TextField-28"></label>
<input type="text" name="RESULT_TextField-28" class="text_field read_only" id="RESULT_TextField-28"  size="5" maxlength="255" disabled value="<?php echo $row["COMS459"]; ?>" />
</div>
<div id="q30" class="q">
<a class="item_anchor" name="ItemAnchor29"></a>
<label class="question top_question" for="RESULT_TextField-29"></label>
<input type="text" name="RESULT_TextField-29" class="text_field read_only" id="RESULT_TextField-29"  size="5" maxlength="255" disabled value="<?php echo $row["ELECTIVE5"]; ?>" />
</div>
<div id="q31" class="q">
<a class="item_anchor" name="ItemAnchor30"></a>
<label class="question top_question" for="RESULT_TextField-30"></label>
<input type="text" name="RESULT_TextField-30" class="text_field read_only" id="RESULT_TextField-30"  size="5" maxlength="255" disabled value="<?php echo $row["ELECTIVE6"]; ?>" />
</div>
<div id="q32" class="q">
<a class="item_anchor" name="ItemAnchor31"></a>
<label class="question top_question" for="RESULT_TextField-31"></label>
<input type="text" name="RESULT_TextField-31" class="text_field read_only" id="RESULT_TextField-31"  size="5" maxlength="255" disabled value="" />
</div>
<br><br>
<div class="clear"></div>

<div id="q33" class="q">
<a class="item_anchor" name="ItemAnchor32"></a>
<label class="question top_question" for="RESULT_TextField-32">Fifth Sem:</label>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
<input type="text" name="RESULT_TextField-32" class="text_field read_only" id="RESULT_TextField-32"  size="5" maxlength="255" disabled value="<?php echo $row["COMS501"]; ?>" />
</div>
<div id="q34" class="q">
<a class="item_anchor" name="ItemAnchor33"></a>
<label class="question top_question" for="RESULT_TextField-33"></label>
<input type="text" name="RESULT_TextField-33" class="text_field read_only" id="RESULT_TextField-33"  size="5" maxlength="255" disabled value="<?php echo $row["COMS502"]; ?>" />
</div>
<div id="q35" class="q">
<a class="item_anchor" name="ItemAnchor34"></a>
<label class="question top_question" for="RESULT_TextField-34"></label>
<input type="text" name="RESULT_TextField-34" class="text_field read_only" id="RESULT_TextField-34"  size="5" maxlength="255" disabled value="<?php echo $row["COMS508"]; ?>" />
</div>
<div id="q36" class="q">
<a class="item_anchor" name="ItemAnchor35"></a>
<label class="question top_question" for="RESULT_TextField-35"></label>
<input type="text" name="RESULT_TextField-35" class="text_field read_only" id="RESULT_TextField-35"  size="5" maxlength="255" disabled value="<?php echo $row["COMS509"]; ?>" />
</div>
<div id="q37" class="q">
<a class="item_anchor" name="ItemAnchor36"></a>
<label class="question top_question" for="RESULT_TextField-36"></label>
<input type="text" name="RESULT_TextField-36" class="text_field read_only" id="RESULT_TextField-36"  size="5" maxlength="255" disabled value="<?php echo $row["ELECTIVE7"]; ?>" />
</div>
<div id="q38" class="q">
<a class="item_anchor" name="ItemAnchor37"></a>
<label class="question top_question" for="RESULT_TextField-37"></label>
<input type="text" name="RESULT_TextField-37" class="text_field read_only" id="RESULT_TextField-37"  size="5" maxlength="255" disabled value="<?php echo $row["ELECTIVE8"]; ?>" />
</div>
<div id="q39" class="q">
<a class="item_anchor" name="ItemAnchor38"></a>
<label class="question top_question" for="RESULT_TextField-38"></label>
<input type="text" name="RESULT_TextField-38" class="text_field read_only" id="RESULT_TextField-38"  size="5" maxlength="255" disabled value="<?php echo $row["ELECTIVE9"]; ?>" />
</div>
<div id="q40" class="q">
<a class="item_anchor" name="ItemAnchor39"></a>
<label class="question top_question" for="RESULT_TextField-39"></label>
<input type="text" name="RESULT_TextField-39" class="text_field read_only" id="RESULT_TextField-39"  size="5" maxlength="255" disabled value="" />
</div>
<br><br>
<div class="clear"></div>

<div id="q41" class="q">
<a class="item_anchor" name="ItemAnchor40"></a>
<label class="question top_question" for="RESULT_TextField-40">Sixth Sem</label>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
<input type="text" name="RESULT_TextField-40" class="text_field read_only" id="RESULT_TextField-40"  size="5" maxlength="255" disabled value="<?php echo $row["COMS561"]; ?>" />
</div>
<div id="q42" class="q">
<a class="item_anchor" name="ItemAnchor41"></a>
<label class="question top_question" for="RESULT_TextField-41"></label>
<input type="text" name="RESULT_TextField-41" class="text_field read_only" id="RESULT_TextField-41"  size="5" maxlength="255" disabled value="<?php echo $row["COMS562"]; ?>" />
</div>
<div id="q43" class="q">
<a class="item_anchor" name="ItemAnchor42"></a>
<label class="question top_question" for="RESULT_TextField-42"></label>
<input type="text" name="RESULT_TextField-42" class="text_field read_only" id="RESULT_TextField-42"  size="5" maxlength="255" disabled value="<?php echo $row["COMS563"]; ?>" />
</div>
<div id="q44" class="q">
<a class="item_anchor" name="ItemAnchor43"></a>
<label class="question top_question" for="RESULT_TextField-43"></label>
<input type="text" name="RESULT_TextField-43" class="text_field read_only" id="RESULT_TextField-43"  size="5" maxlength="255" disabled value="" />
</div>
<div id="q45" class="q">
<a class="item_anchor" name="ItemAnchor44"></a>
<label class="question top_question" for="RESULT_TextField-44"></label>
<input type="text" name="RESULT_TextField-44" class="text_field read_only" id="RESULT_TextField-44"  size="5" maxlength="255" disabled value="" />
</div>
<div id="q46" class="q">
<a class="item_anchor" name="ItemAnchor45"></a>
<label class="question top_question" for="RESULT_TextField-45"></label>
<input type="text" name="RESULT_TextField-45" class="text_field read_only" id="RESULT_TextField-45"  size="5" maxlength="255" disabled value="" />
</div>
<div id="q47" class="q">
<a class="item_anchor" name="ItemAnchor46"></a>
<label class="question top_question" for="RESULT_TextField-46"></label>
<input type="text" name="RESULT_TextField-46" class="text_field read_only" id="RESULT_TextField-46"  size="5" maxlength="255" disabled value="" />
</div>
<div id="q48" class="q">
<a class="item_anchor" name="ItemAnchor47"></a>
<label class="question top_question" for="RESULT_TextField-47"></label>
<input type="text" name="RESULT_TextField-47" class="text_field read_only" id="RESULT_TextField-47"  size="5" maxlength="255" disabled value="" />
</div>
<?php
	}
}
?>
<br><br>	<br><br><br><br>
<label style="color:RED" ><b>Note :</b>Results are according to the courses registered above.<label>
</div>
</div>
<div><br></div>

<script>
var acc = document.getElementsByClassName("accordion");
var i;

for (i = 0; i < acc.length; i++) {
    acc[i].onclick = function(){
        this.classList.toggle("active");
        this.nextElementSibling.classList.toggle("show");
  }
}
</script>

	<?php
	$conn->close();
	
	?>

	<head>
<style>
/* The Modal (background) */
.modal {
    display: none; /* Hidden by default */
    position: fixed; /* Stay in place */
    z-index: 1; /* Sit on top */
    padding-top: 100px; /* Location of the box */
    left: 0;
    top: 0;
    width: 100%; /* Full width */
    height: 100%; /* Full height */
    overflow: auto; /* Enable scroll if needed */
    background-color: rgb(0,0,0); /* Fallback color */
    background-color: rgba(0,0,0,0.4); /* Black w/ opacity */
}

/* Modal Content */
.modal-content {
    position: relative;
    background-color: #fefefe;
    margin: auto;
    padding: 0;
    border: 1px solid #888;
    width: 80%;
    box-shadow: 0 4px 8px 0 rgba(0,0,0,0.2),0 6px 20px 0 rgba(0,0,0,0.19);
    -webkit-animation-name: animatetop;
    -webkit-animation-duration: 0.4s;
    animation-name: animatetop;
    animation-duration: 0.4s
}

/* Add Animation */
@-webkit-keyframes animatetop {
    from {top:-300px; opacity:0} 
    to {top:0; opacity:1}
}

@keyframes animatetop {
    from {top:-300px; opacity:0}
    to {top:0; opacity:1}
}

/* The Close Button */
.close {
    color: white;
    float: right;
    font-size: 28px;
    font-weight: bold;
}

.close:hover,
.close:focus {
    color: #000;
    text-decoration: none;
    cursor: pointer;
}

.modal-header {
    padding: 2px 16px;
    background-color: #5cb85c;
    color: white;
}

.modal-body {padding: 2px 16px;}

.modal-footer {
    padding: 2px 16px;
    background-color: #5cb85c;
    color: white;
}
</style>
</head>
<body>
<!-- Trigger/Open The Modal -->
<!-- The Modal -->
<div id="myModal" class="modal">
<!-- Modal content -->
  <div class="modal-content">
    <div class="modal-header">
      <span class="close">x</span>
      <h2>Thank You for using student portal</h2>
    </div>
    <div class="modal-body">
      <b><p>Logged Out Successfully</p><b>
      
    </div>
    <div class="modal-footer">
      <h3>You will be redirected to Student Login Page</h3>
    </div>
  </div>
</div>

<script>
// Get the modal
var modal = document.getElementById('myModal');

// Get the button that opens the modal
var btn = document.getElementById("myBtn");

// Get the <span> element that closes the modal
var span = document.getElementsByClassName("close")[0];

// When the user clicks the button, open the modal 
btn.onclick = function() {
    modal.style.display = "block";
}

// When the user clicks on <span> (x), close the modal
span.onclick = function() {
    modal.style.display = "none";
}

// When the user clicks anywhere outside of the modal, close it
window.onclick = function(event) {
    if (event.target == modal) {
        modal.style.display = "none";
    }
}
</script>
	
</body>
</html>

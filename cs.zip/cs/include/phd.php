
 <div class="panel panel-primary" >
			  <div class="panel-heading" style="background-color: #4db8ff;">
			        <h3 class="panel-title" style="text-align: center;"><b>Ph.D. COMPUTER SCIENCE</b></h3>
			  </div>
			  <div class="panel-body">
			       The Department of Computer Science offers Ph.D. Computer Science & Engineering [Full-time, Part-time (Internal & External)]
			  </div>
			  <div class="panel-heading" style="background-color:#4dd2ff;">
			        <h3 class="panel-title" style="color: black;" ><b>MODE OF ADMISSION</b></h3>
			  </div>
			  <div class="panel-body">
			        Admission to Ph.D. is based on entrance examination. The entrance examination is of objective type
			  </div>
			  <div class="panel-heading" style="background-color:#80dfff;">
			        <h3 class="panel-title" style="color: black;"><b>SYLLABUS FOR TEST</b></h3>
			  </div>
			  <div class="panel-body">
			        The question paper will consist of 100 questions covering all the relevant topics from Computer Science and Engineering at P. G. level. The NET/JRF qualified candidates with fellowships will be given direct admission to Ph.D programmes. All others (including non-fellowship NET and GATE qualified candidates) will have to appear for the entrance examination.
			        <br>
			        There will be viva cum interview conducted after the entrance test
			  </div>
			  <div class="panel-heading" style="background-color:#85e0e0;">
			        <h3 class="panel-title" style="color: black;"><b>RESULT PUBLICATION</b></h3>
			  </div>
			  <div class="panel-body">
			        The list of qualified students will be published on the University website on merit basis and viva-interview, the councelling date will be mentioned there.
			        <br>Rank list will be based on the marks scored in the entrace test and interview.
			  </div>
			  
</div>
